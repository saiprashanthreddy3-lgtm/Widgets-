package com.glasswidgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/** Time and date are drawn live by TextClock, so no refresh timer is needed. */
class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = RemoteViews(context.packageName, R.layout.clock_widget)
        views.setOnClickPendingIntent(
            R.id.root,
            Common.openPending(context, 1, *Common.clockIntents())
        )
        for (id in ids) mgr.updateAppWidget(id, views)
    }
}
