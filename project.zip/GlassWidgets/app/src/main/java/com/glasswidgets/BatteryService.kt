package com.glasswidgets

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder

/**
 * Keeps the battery widget live. Android only delivers battery-level changes to a
 * receiver registered while the app is running, so this small foreground service
 * holds that receiver. It does no work between battery changes.
 */
class BatteryService : Service() {

    private var lastLevel = -1
    private var lastPlugged = -1

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            if (level != lastLevel || plugged != lastPlugged) {
                lastLevel = level
                lastPlugged = plugged
                BatteryWidget.updateAll(applicationContext)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Battery widget", NotificationManager.IMPORTANCE_MIN)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Battery widget is live")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "battery_live"

        fun hasBatteryWidget(context: Context): Boolean {
            val mgr = AppWidgetManager.getInstance(context)
            return mgr.getAppWidgetIds(ComponentName(context, BatteryWidget::class.java)).isNotEmpty()
        }

        fun start(context: Context) {
            try {
                context.startForegroundService(Intent(context, BatteryService::class.java))
            } catch (_: Exception) {
                // Android refused a background start; opening the app once starts it.
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BatteryService::class.java))
        }
    }
}
