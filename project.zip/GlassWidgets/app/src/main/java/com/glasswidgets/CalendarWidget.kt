package com.glasswidgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.widget.RemoteViews
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CalendarWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = build(context)
        for (id in ids) mgr.updateAppWidget(id, views)
        Common.scheduleMidnight(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                updateAll(context)
                Common.scheduleMidnight(context)
            }
        }
    }

    override fun onEnabled(context: Context) {
        Common.scheduleMidnight(context)
    }

    override fun onDisabled(context: Context) {
        Common.cancelMidnight(context)
    }

    companion object {
        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, CalendarWidget::class.java))
            if (ids.isEmpty()) return
            mgr.updateAppWidget(ids, build(context))
        }

        private fun build(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.calendar_widget)
            views.setImageViewBitmap(R.id.month, drawMonth())
            views.setOnClickPendingIntent(
                R.id.root,
                Common.openPending(context, 2, *Common.calendarIntents())
            )
            return views
        }

        /** Month grid, weeks start on Monday (M T W T F S S), today in a white circle. */
        private fun drawMonth(): Bitmap {
            val w = 700
            val h = 700
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)

            val now = Calendar.getInstance()
            val today = now.get(Calendar.DAY_OF_MONTH)
            val first = now.clone() as Calendar
            first.set(Calendar.DAY_OF_MONTH, 1)
            val daysInMonth = now.getActualMaximum(Calendar.DAY_OF_MONTH)
            // Calendar: Sunday=1..Saturday=7  ->  Monday=0..Sunday=6
            val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
            val rows = (offset + daysInMonth + 6) / 7

            val medium = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            val bold = Typeface.create("sans-serif", Typeface.BOLD)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

            val left = 20f
            val colW = (w - 2 * left) / 7f

            // Month title
            val title = SimpleDateFormat("MMMM", Locale.getDefault()).format(now.time).uppercase()
            paint.typeface = bold
            paint.textSize = 44f
            paint.color = 0xFFFFFFFF.toInt()
            paint.textAlign = Paint.Align.LEFT
            c.drawText(title, left + 6f, 70f, paint)

            // Weekday letters, Monday first
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = bold
            paint.textSize = 32f
            val names = DateFormatSymbols.getInstance(Locale.getDefault()).shortWeekdays
            val order = intArrayOf(2, 3, 4, 5, 6, 7, 1)
            for (col in 0 until 7) {
                val letter = names[order[col]].take(1).uppercase()
                paint.color = if (col >= 5) 0x99FFFFFF.toInt() else 0xCCFFFFFF.toInt()
                c.drawText(letter, left + colW * col + colW / 2, 135f, paint)
            }

            // Day numbers
            val gridTop = 170f
            val rowH = minOf((h - gridTop - 10f) / rows, 100f)
            paint.textSize = 38f
            val fm = paint.fontMetrics
            val textShift = -(fm.ascent + fm.descent) / 2f

            for (day in 1..daysInMonth) {
                val idx = offset + day - 1
                val row = idx / 7
                val col = idx % 7
                val cx = left + colW * col + colW / 2
                val cy = gridTop + rowH * row + rowH / 2

                if (day == today) {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xFFFFFFFF.toInt()
                    c.drawCircle(cx, cy, minOf(colW, rowH) * 0.46f, paint)
                    paint.typeface = bold
                    paint.color = 0xFF1C1C1E.toInt()
                } else {
                    paint.typeface = medium
                    paint.color = if (col >= 5) 0x99FFFFFF.toInt() else 0xFFFFFFFF.toInt()
                }
                c.drawText(day.toString(), cx, cy + textShift, paint)
            }
            return bmp
        }
    }
}
