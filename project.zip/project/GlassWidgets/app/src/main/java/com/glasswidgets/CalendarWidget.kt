package com.glasswidgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*

class CalendarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    companion object {
        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.calendar_widget)

            val calendar = Calendar.getInstance()
            val monthFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
            val dayNumFormat = SimpleDateFormat("d", Locale.getDefault())
            val dayNameFormat = SimpleDateFormat("EEEE", Locale.getDefault())

            val monthStr = monthFormat.format(calendar.time).uppercase(Locale.getDefault())
            val dayNumStr = dayNumFormat.format(calendar.time)
            val dayNameStr = dayNameFormat.format(calendar.time).uppercase(Locale.getDefault())

            views.setTextViewText(R.id.tv_calendar_month, monthStr)
            views.setTextViewText(R.id.tv_calendar_day_num, dayNumStr)
            views.setTextViewText(R.id.tv_calendar_day_name, dayNameStr)

            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build()
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 2, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.calendar_layout, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
