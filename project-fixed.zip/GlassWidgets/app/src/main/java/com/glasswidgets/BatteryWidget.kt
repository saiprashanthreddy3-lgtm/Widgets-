package com.glasswidgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.BatteryManager
import android.view.View
import android.widget.RemoteViews

class BatteryWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = build(context)
        for (id in ids) mgr.updateAppWidget(id, views)
        BatteryService.start(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED,
            Intent.ACTION_POWER_DISCONNECTED,
            Intent.ACTION_BATTERY_LOW,
            Intent.ACTION_BATTERY_OKAY -> updateAll(context)
        }
    }

    override fun onEnabled(context: Context) {
        BatteryService.start(context)
    }

    override fun onDisabled(context: Context) {
        BatteryService.stop(context)
    }

    companion object {
        private const val GREEN = 0xFF34C759.toInt()
        private const val RED = 0xFFFF3B30.toInt()

        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, BatteryWidget::class.java))
            if (ids.isEmpty()) return
            mgr.updateAppWidget(ids, build(context))
        }

        private fun build(context: Context): RemoteViews {
            val sticky = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = sticky?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = sticky?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val plugged = (sticky?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale).coerceIn(0, 100) else 0

            val views = RemoteViews(context.packageName, R.layout.battery_widget)
            views.setImageViewBitmap(R.id.ring, drawRing(pct, plugged))
            views.setTextViewText(R.id.percent, "$pct%")
            views.setTextViewText(R.id.status, if (plugged) "Charging" else "")
            views.setViewVisibility(R.id.status, if (plugged) View.VISIBLE else View.GONE)
            views.setOnClickPendingIntent(
                R.id.root,
                Common.openPending(context, 3, *Common.batteryIntents())
            )
            return views
        }

        private fun drawRing(pct: Int, charging: Boolean): Bitmap {
            val size = 240
            val stroke = 26f
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val rect = RectF(stroke / 2, stroke / 2, size - stroke / 2, size - stroke / 2)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = stroke
                strokeCap = Paint.Cap.ROUND
            }
            // Track
            paint.color = 0x66FFFFFF
            c.drawArc(rect, 0f, 360f, false, paint)
            // Progress
            paint.color = if (pct <= 20 && !charging) RED else GREEN
            if (pct > 0) c.drawArc(rect, -90f, 360f * pct / 100f, false, paint)

            // Phone icon in the middle
            val cx = size / 2f
            val cy = size / 2f
            val w = size * 0.26f
            val h = size * 0.44f
            val body = RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = 0x40FFFFFF
            }
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 7f
                color = 0xE6FFFFFF.toInt()
            }
            c.drawRoundRect(body, 14f, 14f, fill)
            c.drawRoundRect(body, 14f, 14f, line)
            // Notch
            line.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx - w * 0.14f, body.top + 14f, cx + w * 0.14f, body.top + 14f, line)

            if (charging) {
                val bolt = Path().apply {
                    moveTo(cx + 0.02f * size, cy - 0.12f * size)
                    lineTo(cx - 0.06f * size, cy + 0.02f * size)
                    lineTo(cx, cy + 0.02f * size)
                    lineTo(cx - 0.02f * size, cy + 0.12f * size)
                    lineTo(cx + 0.06f * size, cy - 0.03f * size)
                    lineTo(cx, cy - 0.03f * size)
                    close()
                }
                val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = Color.WHITE
                }
                c.drawPath(bolt, boltPaint)
            }
            return bmp
        }
    }
}
