package com.glasswidgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/** Time and date are drawn live by TextClock, so no refresh timer is needed. */
class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val views = RemoteViews(context.packageName, R.layout.clock_widget)
        val tap = Common.openPending(context, 1, *Common.clockIntents())
        views.setOnClickPendingIntent(R.id.root, tap)
        views.setOnClickPendingIntent(R.id.date, tap)
        views.setOnClickPendingIntent(R.id.time, tap)
        for (id in ids) mgr.updateAppWidget(id, views)
    }
}
