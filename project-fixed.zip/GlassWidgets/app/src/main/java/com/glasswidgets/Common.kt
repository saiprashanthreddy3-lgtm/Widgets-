package com.glasswidgets

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import java.util.Calendar

object Common {
    private const val MIDNIGHT_CODE = 9001
    const val ACTION_MIDNIGHT = "com.glasswidgets.MIDNIGHT"

    /** Tap action: opens the first intent that this phone can handle, else this app. */
    fun openPending(context: Context, requestCode: Int, vararg candidates: Intent): PendingIntent {
        val pm = context.packageManager
        val intent = candidates.firstOrNull { it.resolveActivity(pm) != null }
            ?: pm.getLaunchIntentForPackage(context.packageName)
            ?: Intent()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun clockIntents(): Array<Intent> = arrayOf(Intent(AlarmClock.ACTION_SHOW_ALARMS))

    fun calendarIntents(): Array<Intent> = arrayOf(
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR),
        Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time"))
    )

    fun batteryIntents(): Array<Intent> = arrayOf(
        Intent(Intent.ACTION_POWER_USAGE_SUMMARY),
        Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
    )

    private fun midnightPending(context: Context): PendingIntent {
        val i = Intent(context, RefreshReceiver::class.java).setAction(ACTION_MIDNIGHT)
        return PendingIntent.getBroadcast(
            context, MIDNIGHT_CODE, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** One alarm for the next 12:00 AM. It re-schedules itself each night. */
    fun scheduleMidnight(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 1)
            set(Calendar.MILLISECOND, 0)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC, cal.timeInMillis, midnightPending(context))
    }

    fun cancelMidnight(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(midnightPending(context))
    }
}
