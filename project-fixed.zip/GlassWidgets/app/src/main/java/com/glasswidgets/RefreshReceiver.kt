package com.glasswidgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fires at 12:00 AM: redraws the calendar and sets the next midnight alarm. */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        CalendarWidget.updateAll(context)
        Common.scheduleMidnight(context)
    }
}
