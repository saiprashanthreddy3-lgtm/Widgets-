package com.glasswidgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a restart: bring back the live battery updates and the midnight alarm. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (BatteryService.hasBatteryWidget(context)) BatteryService.start(context)
        Common.scheduleMidnight(context)
    }
}
